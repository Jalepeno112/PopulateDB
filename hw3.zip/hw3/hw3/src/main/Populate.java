/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.sql.*;
import org.json.simple.*;
import java.io.*;
import java.util.Scanner;

//import oracle.jdbc.OracleDriver;

/**
 *
 * @author giovannib
 */
public class Populate {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      System.out.println("Hello world");
      Populate pop = new Populate();
      pop.run(args);

    }


   public void run(String [] args) {
     for (int i = 0; i < args.length; i++) {
       System.out.println(i + ": " + args[i]);

       // declare scanner
       Scanner s = null;

       // try and open a file and read the data
       // if we can succesfully open the file, then we will remove all entries from the current table
       //    DELETE FROM <table_name>
       // then we will insert new data
       //    INSERT INTO <table_name> VALUES(<array of values>)
       try {
          s = new Scanner(new File(args[i]));

          String table_name = args[i].substring(0, args[i].lastIndexOf('.'));
          table_name = table_name.substring(table_name.lastIndexOf("/")+1);

          System.out.println("TABLE NAME: " + table_name);

          Connection con = null;

          // for each line in the file, we want to make an entry into our database
          // we need to split the line into the components, construct the Insert statements, and then insert
          //
          while (s.hasNextLine()) {
              String line = s.nextLine();
              String[] split=line.split("\t");
              //System.out.println(split);
          }

          try {
            System.out.println("Opening connection");
            con = openConnection();
            System.out.println('Connection made!');
          } catch (SQLException e) {
            System.err.println("Errors occurs when communicating with the database server: " + e.getMessage());
          } catch (ClassNotFoundException e) {
             System.err.println("Cannot find the database driver");
          } catch (Throwable any) {
             System.out.println("Java ERROR: "+any);
             any.printStackTrace();
           }finally {
             // Never forget to close database connection
             closeConnection(con);
          }
       }catch(FileNotFoundException fnfe) {
           System.out.println("ERROR: " + fnfe.getMessage());
       } finally {
          if (s != null) {
              s.close();
          }
       }
     }

   }
   /**
    *
    * @return a database connection
    * @throws SQLException when there is an error when trying to connect database
    * @throws ClassNotFoundException when the database driver is not found.
    */
   private Connection openConnection() throws SQLException, ClassNotFoundException {
       // Load the Oracle database driver
       System.out.println("openConnection");
       System.out.println("Registering Driver");

       //System.out.println(oracle.jdbc.OracleDriver);

       DriverManager.registerDriver(new oracle.jdbc.OracleDriver());

       /*
       Here is the information needed when connecting to a database
       server. These values are now hard-coded in the program. In
       general, they should be stored in some configuration file and
       read at run time.
       */
       String host = "dagobah.engr.scu.edu";
       String port = "1521";
       String dbName = "db11g";
       String userName = "gbriggs";
       String password = "FusRoDah112";

       // Construct the JDBC URL
       String dbURL = "jdbc:oracle:thin:@" + host + ":" + port + ":" + dbName;

       System.out.println("Attempting connection!");
       return DriverManager.getConnection(dbURL, userName, password);
   }

   /**
    * Close the database connection
    * @param con
    */
   private void closeConnection(Connection con) {
       try {
           con.close();
       } catch (SQLException e) {
           System.err.println("Cannot close connection: " + e.getMessage());
       }
   }
}
